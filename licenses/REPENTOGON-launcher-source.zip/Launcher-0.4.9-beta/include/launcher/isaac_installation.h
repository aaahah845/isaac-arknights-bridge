#pragma once

#include <optional>
#include <string>
#include <variant>

#include "shared/loggable_gui.h"

struct Version {
    /* Hash of a given version. */
    const char* hash;
    /* User-friendly string associated with this version. */
    const char* version;
    /* Whether the version is compatible with Repentogon or not. */
    bool valid;
};

enum ReadVersionStringResult {
    READ_VERSION_STRING_OK,
    READ_VERSION_STRING_ERR_NO_FILE,
    READ_VERSION_STRING_ERR_OPEN,
    READ_VERSION_STRING_ERR_NO_MEM,
    READ_VERSION_STRING_ERR_TOO_BIG,
    READ_VERSION_STRING_ERR_INVALID_PE,
    READ_VERSION_STRING_ERR_NO_VERSION
};

enum IsaacPatchAvailability {
	ISAAC_PATCH_NOT_CHECKED,
	ISAAC_PATCH_NOT_AVAILABLE,
	ISAAC_PATCH_AVAILABLE,
	ISAAC_PATCH_ONLINE_CHECK_FAILED,
};

/* Global array of all known versions of the game. */
extern Version const knownVersions[];

class InstallationData {
private:
    std::string _exePath;
    std::string _folderPath;
    std::variant<const Version*, std::string> _version;
    bool _isCompatibleWithRepentogon = false;
    std::string _CompatReason = "Maybe it works?, probably not tho, try it!";
    bool _isValid = false;
    bool _needsPatch = false;
	IsaacPatchAvailability _patchAvailability = ISAAC_PATCH_NOT_CHECKED;

    mutable ILoggableGUI* _gui = nullptr;

    static std::optional<std::string> ComputeVersion(std::string const& path);
    static std::optional<std::string> GetVersionStringFromMemory(std::string const& path);
    static std::string StripVersion(std::string const& version);

    // Returns true if a patch is available to convert this version into a supported one.
    bool PatchIsAvailable(bool skipOnlineCheck = false);
    std::string patchtargetversion = "v1.9.7.12.J273";

public:
    inline void SetGUI(ILoggableGUI* gui) {
        _gui = gui;
    }

    bool Validate(std::string const& path, bool repentogon);
    bool ValidateExecutable(std::string const& path);
    bool DoValidateExecutable(std::string const& path) const;

    inline bool IsCompatibleWithRepentogon() const {
        return _isCompatibleWithRepentogon;
    }

    inline bool NeedsPatch() const {
        return _needsPatch;
    }

    inline bool IsValid() const {
        return _isValid;
    }

    inline std::string GetUpdatedReason() const { //instalationdata is a const in a lot of places and I dont think this alone justifies changing it(or maybe Im just too lazy to do it rn)...so, here goes nothing.
        if (_isCompatibleWithRepentogon) {
            if (_needsPatch) {
                return "Will work, the launcher has a patch to adapt it to a compatible version.";
            }
            else {
                return "Should just work.";
            }
        }
        else {
            if (!strncmp(GetVersion(), "v1.7", strlen("v1.7"))) {
                return "You need the Repentance+ dlc, you currently only have Repentance installed (WHICH IS NOT THE SAME).";
            }
            else {
                return "You dont have a proper version or your exe is corrupted/cracked \n(verify your files with steam or download the specific version rgon uses)";
            }
        }
        return _CompatReason;
    }

    inline std::string UpdateReason() {
        _CompatReason = GetUpdatedReason();
        return _CompatReason;
    }

    inline std::string GetReason() const {
        return _CompatReason;
    }

    inline const char* GetVersion() const {
        if (std::holds_alternative<const Version*>(_version)) {
            const Version* version = std::get<const Version*>(_version);
            if (!version)
                return "";
            else
                return version->version;
        } else {
            return std::get<std::string>(_version).c_str();
        }
    }

    inline std::string const& GetExePath() const {
        return _exePath;
    }

    inline std::string const& GetFolderPath() const {
        return _folderPath;
    }
};

class IsaacInstallation {
public:
    IsaacInstallation(ILoggableGUI* gui);

    bool Validate(std::string const& exePath);
    bool ValidateRepentogon(std::string const& folderPath);
    std::optional<std::string> AutoDetect();
	std::string GetSaveDataFolderPath() const;
	std::string GetLogFilePath() const;
	std::string GetOptionsIniPath() const;

    InstallationData const& GetMainInstallation() const {
        return _mainInstallation;
    }

    InstallationData const& GetRepentogonInstallation() const {
        return _repentogonInstallation;
    }

	inline void SetGUI(ILoggableGUI* gui) {
		_gui = gui;
	}

private:
    mutable ILoggableGUI* _gui;

    inline InstallationData& GetInstallationData(bool repentogon = false) {
        return repentogon ? _repentogonInstallation : _mainInstallation;
    }

    InstallationData _mainInstallation;
    InstallationData _repentogonInstallation;
};