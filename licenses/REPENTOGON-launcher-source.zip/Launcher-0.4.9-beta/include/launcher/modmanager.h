#pragma once

#include <vector>
#include <string>
#include <filesystem>
#include <unordered_map>

#include "launcher/windows/launcher.h"
#include "wx/wx.h"
#include "wx/listbox.h"
#include "wx/textctrl.h"
#include "wx/richtext/richtextctrl.h"

namespace fs = std::filesystem;

struct ModExtraData {
    bool lua = false;
    bool anm2 = false;
    bool sprites = false;

    bool Items = false;
    bool Trinkets = false;
    bool Characters = false;
    bool Music = false;
    bool Sounds = false;
    bool Challenges = false;
    bool ItemPools = false;
    bool Cards = false;
    bool Pills = false;
    bool Shaders = false;

    bool resourceItems = false;
    bool resourceTrinkets = false;
    bool resourceCharacters = false;
    bool resourceMusic = false;
    bool resourceSounds = false;
    bool resourceChallenges = false;
    bool resourceItemPools = false;
    bool resourceCards = false;
    bool resourcePills = false;
    bool resourceShaders = false;
    bool cutscenes = false;

    bool resourceMinor = false;

    bool dataset = false;
};

struct ModInfo {
    std::wstring folderName;
    std::wstring displayName;
    std::string description;
    std::wstring directory;
    bool islocal;
    std::wstring id;
    ModExtraData extradata;
};

class ModManagerFrame : public wxFrame { //Thought of making it a dialog, but I dont think it makes that much sense here
public:
    ModManagerFrame(wxWindow* parent, Launcher::Installation* Instalation);
    void RefreshLists();

    void OnThreadUpdate(wxThreadEvent& evt) {
        wxBitmap bmp = evt.GetPayload<wxBitmap>();
        thumbnailCtrl->SetBitmap(bmp);
    }

private:
    wxStaticBitmap* thumbnailCtrl;
    wxRichTextCtrl* descriptionCtrl;
    wxRichTextCtrl* extraInfoCtrl;

    ModInfo selectedMod;
    wxStaticText* selectedModTitle;

    wxListBox* _enabledlist;
    wxListBox* _disabledlist;
    wxTextCtrl* _searchctrl;
    
    fs::path _modspath;

    std::vector<ModInfo> allMods;
    std::unordered_map<std::wstring, ModInfo> modMap;

    void LoadModsFromFolder();

    void OnEnableAll(wxCommandEvent& event);
    void OnDisableAll(wxCommandEvent& event);
    void OnDoubleClickEnabled(wxCommandEvent& event);
    void OnDoubleClickDisabled(wxCommandEvent& event);
    void OnSearch(wxCommandEvent& event);
    void OnSave(wxCommandEvent& event);
    void OnLoad(wxCommandEvent& event);
    void OnClose(wxCommandEvent& event);

    void LoadModExtraData();
    void OnSelectModEnabled(wxCommandEvent& event);
    void OnSelectModDisabled(wxCommandEvent& event);
    void OnSelectMod(ModInfo mod);
    void OnWorkshopPage(wxCommandEvent& event);
    void OnModFolder(wxCommandEvent& event);
    void OnModSaveFolder(wxCommandEvent& event);
	void OnReinstall(wxCommandEvent& event);

    void OnHover(wxMouseEvent& event);

    void EnableMod(const std::wstring& modfolder);
    void DisableMod(const std::wstring& modfolder);
    bool IsDisabled(const std::wstring& modfolder);

    wxDECLARE_EVENT_TABLE();
};

class ModManagerReinstallDialog : public wxDialog {
public:
	ModManagerReinstallDialog(wxWindow* parent, const uint64_t workshopid, const std::wstring& modname);

	void OnCancel(wxCommandEvent&);
	void OnTimer(wxTimerEvent& event);
	void OnThreadUpdate(wxThreadEvent& evt);
	void TryReinstallMod();
	void MainProc();

private:
	const uint64_t workshopid_;

	wxStaticText* statusLabel_ = nullptr;
	wxGauge* progressBar_ = nullptr;
	std::unique_ptr<wxTimer> timer_ = nullptr;
	wxButton* cancelButton_ = nullptr;
	std::atomic<bool> cancelRequested_ = false;
};
