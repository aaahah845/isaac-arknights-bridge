#include <WinSock2.h>
#include <Windows.h>
#include <WinBase.h>
#include <filesystem>
#include <Commctrl.h>
#include <thread>
#include <memory>
#include <fstream>
#include <set>

#include "shared/github_executor.h"
#include "shared/filesystem.h"
#include "shared/logger.h"
#include "shared/utils.h"
#include "self_updater/self_updater.h"
#include "self_updater/utils.h"
#include "self_updater/launcher_update_manager.h"
#include "self_updater/unique_window.h"
#include "launcher/version.h"
#include "zip.h"


// Enables windows visual styles for a nicer-looking progress bar & the marquee style.
// Incantation obtained from official docs: https://learn.microsoft.com/en-us/windows/win32/controls/cookbook-overview
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")

const char* Updater::ForcedArg = "--force";
const char* Updater::UnstableArg = "--unstable";
const char* Updater::LauncherProcessIdArg = "--launcherpid";
const char* Updater::ReleaseURL = "--url";
const char* Updater::UpgradeVersion = "--version";

namespace Updater {
	static const char* LauncherBinFilename = "launcher-data.bin";
	static const char* LauncherBinBackupFilename = "launcher-data.bin.bak";
	static const char* LauncherDllPath = "./launcher-data/REPENTOGONLauncherApp.dll";
	static const char* UpdaterProcessName = "REPENTOGON Launcher Updater";

	// During update installation, the existing updater exe is renamed to make room for the new one.
	// We can't delete our own exe (since it is obviously running) but renaming it is allowed.
	// The old renamed exe will be deleted the next time the updater runs.
	static const char* UpdaterExeFilename = "REPENTOGONLauncher.exe";
	static const char* RenamedUpdaterExeFilename = "REPENTOGONLauncher.exe.bak";

	// Files related to legacy versions that should be deleted if found.
	static const std::set<std::string> LegacyCleanupFiles = {
		"REPENTOGONLauncherUpdater.exe",
		"REPENTOGONLauncherUpdater.exe.bak",
	};

	static const char* LauncherDataFolder = "launcher-data";
	static const char* LauncherDataBackupFolder = "launcher-data.old";
	static const char* UpdateStagingFolder = "launcher-update";
	static const char* UnfinishedUpdateMarker = "launcher-data/unfinished.it";

	const char* CheckSelfUpdateLauncherArg = "--check-self-update";

	const std::unordered_map<UpdaterState, const char*> UpdaterStateProgressBarLabels = {
		{ UPDATER_CHECKING_FOR_UPDATE, "Checking for update..." },
		{ UPDATER_DOWNLOADING_UPDATE, "Downloading update..." },
		{ UPDATER_INSTALLING_UPDATE, "Installing update..." },
		{ UPDATER_STARTING_LAUNCHER, "Starting launcher..." },
	};

	std::atomic<UpdaterState> _currentState = UPDATER_STARTUP;

	std::atomic<bool> _cancelRequested = false;

	void CreateUnfinishedUpdateMarker() {
		std::ofstream file(UnfinishedUpdateMarker);
		file.close();
	}

	bool UnfinishedUpdateMarkerExists() {
		return Filesystem::SafeExists(UnfinishedUpdateMarker);
	}

	void DeleteUnfinishedUpdateMarker() {
		if (UnfinishedUpdateMarkerExists()) {
			std::filesystem::remove(UnfinishedUpdateMarker);
		}
	}
}

Updater::UpdaterState Updater::GetCurrentUpdaterState() {
	return _currentState.load(std::memory_order_acquire);
}

void Updater::SetCurrentUpdaterState(Updater::UpdaterState newState) {
	_currentState.store(newState, std::memory_order_release);
}

int Updater::ShowMessageBox(HWND window, const char* text, UINT flags) {
	if (window) {
		SetForegroundWindow(window);
	}
	return MessageBoxA(window, text, UpdaterProcessName, flags | MB_TOPMOST | MB_SETFOREGROUND);
}

bool Updater::HandleMatchesLauncherExe(HANDLE handle) {
	Logger::Info("HandleMatchesLauncherExe started.\n");

	// Query the name/filepath of the process and verify that it corresponds to the launcher exe.
	char buffer[MAX_PATH];
	DWORD bufferSize = MAX_PATH;
	BOOL getProcessNameSuccess = QueryFullProcessImageNameA(handle, 0, buffer, &bufferSize);
	if (!getProcessNameSuccess) {
		Logger::Error("Error while querying the name of the provided process ID (%d)\n", GetLastError());
		return false;
	}

	Logger::Info("Comparing path of provided process ID (%s) to the launcher exe (%s)\n", buffer, UpdaterExeFilename);

	try {
		return std::filesystem::equivalent(buffer, UpdaterExeFilename);
	}
	catch (const std::filesystem::filesystem_error& err) {
		// Most likely one or the other does not exist.
		Logger::Warn("Error when checking filepath equivalence of `%s` and `%s`: %s", buffer, UpdaterExeFilename, err.what());
	}
	return false;
}

HANDLE Updater::TryOpenLauncherProcessHandle(int argc, char** argv) {
	char* launcherProcessIdParam = Utils::GetLauncherProcessIdArg(argc, argv);
	if (!launcherProcessIdParam) {
		return INVALID_HANDLE_VALUE;
	}

	DWORD launcherProcessId = NULL;
	try {
		launcherProcessId = std::stoul(launcherProcessIdParam);
	} catch (const std::exception& ex) {
		Logger::Error("Failed to parse launcher process ID param from the command line (%s): %s", launcherProcessIdParam, ex.what());
		return INVALID_HANDLE_VALUE;
	}

	HANDLE launcherHandle = OpenProcess(PROCESS_TERMINATE | PROCESS_QUERY_LIMITED_INFORMATION, FALSE, launcherProcessId);
	if (launcherHandle == NULL) {
		// Launcher may have closed already.
		Logger::Warn("Error while trying to open process for provided process ID (%d)\n", GetLastError());
		return INVALID_HANDLE_VALUE;
	}

	DWORD exit_code{};
	if (!GetExitCodeProcess(launcherHandle, &exit_code)) {
		Logger::Warn("Error while trying to check for a launcher exit code (%d)\n", GetLastError());
		return INVALID_HANDLE_VALUE;
	}

	if (exit_code != STILL_ACTIVE) {
		Logger::Warn("Pre-existing Launcher process has already been terminated (%d)\n", exit_code);
		return INVALID_HANDLE_VALUE;
	}

	if (!HandleMatchesLauncherExe(launcherHandle)) {
		// This is not the launcher. Assume that the launcher already closed, and the pid may have been re-used.
		Logger::Warn("Provided process ID is not the launcher exe. Ignoring it.\n");
		CloseHandle(launcherHandle);
		return INVALID_HANDLE_VALUE;
	}

	return launcherHandle;
}

bool Updater::TryDeleteOldRenamedUpdaterExe(HWND mainWindow) {
	int attempts = 0;
	while (Filesystem::SafeExists(RenamedUpdaterExeFilename) && !DeleteFileA(RenamedUpdaterExeFilename)) {
		attempts++;
		if (attempts == 1) {
			Logger::Error("Error trying to delete %s from previous update (%d)\n", RenamedUpdaterExeFilename, GetLastError());
		}
		if (attempts <= 5) {
			std::this_thread::sleep_for(std::chrono::milliseconds(200));
			continue;
		}
		SetCurrentUpdaterState(UPDATER_PROMPTING_USER);
		int response = ShowMessageBox(mainWindow, "Failed to delete REPENTOGONLauncher.exe.bak file from prior update.\n"
			"The update was most likely successful, but please report this as a bug.\n"
			"Select \"cancel\" to allow the Launcher to start.\n", MB_ICONINFORMATION | MB_RETRYCANCEL);
		if (response == IDRETRY || response == IDOK || response == IDTRYAGAIN) {
			std::this_thread::sleep_for(std::chrono::milliseconds(200));
			continue;
		}
		Logger::Error("Failed to delete %s from previous update, and the user chose to cancel.\n", RenamedUpdaterExeFilename);
		return false;
	}

	return true;
}

bool Updater::VerifyLauncherNotRunning(HWND mainWindow) {
	int attempts = 0;
	while (Utils::FileLocked(LauncherDllPath)) {
		attempts++;
		if (attempts == 1) {
			Logger::Error("The launcher exe is currently locked!\n");
		}
		if (attempts <= 5) {
			std::this_thread::sleep_for(std::chrono::milliseconds(200));
			continue;
		}

		int response = ShowMessageBox(mainWindow, "Cannot update the REPENTOGON Launcher, as it is currently running.\nPlease close it and try again.\n", MB_ICONINFORMATION | MB_RETRYCANCEL);
		if (response == IDRETRY || response == IDOK || response == IDTRYAGAIN) {
			std::this_thread::sleep_for(std::chrono::milliseconds(500));
			continue;
		}
		Logger::Error("The launcher is currently running, and the user chose to cancel.\n");
		return false;
	}

	return true;
}

bool Updater::CheckInstallationIntegrity() {
	return !UnfinishedUpdateMarkerExists() && Filesystem::SafeExists(LauncherDllPath);
}

void Updater::CleanInstallation() {
	if (!Updater::CheckInstallationIntegrity()) {
		Logger::Error("Not performing installation cleanup: Integrity check failed!\n");
		return;
	}
	if (Filesystem::SafeExists(LauncherDataBackupFolder)) {
		Logger::Info("Deleting backup folder...\n");
		Filesystem::OneDriveSafeDelete(LauncherDataBackupFolder);
	}
	if (Filesystem::SafeExists(UpdateStagingFolder)) {
		Logger::Info("Deleting staging folder...\n");
		Filesystem::OneDriveSafeDelete(UpdateStagingFolder);
	}
	try {
		if (std::filesystem::exists(LauncherBinBackupFilename)) {
			Logger::Info("Deleting bin backup...\n");
			std::filesystem::remove(LauncherBinBackupFilename);
		}
		if (std::filesystem::exists(RenamedUpdaterExeFilename) && !Utils::FileLocked(RenamedUpdaterExeFilename)) {
			Logger::Info("Deleting old exe...\n");
			std::filesystem::remove(RenamedUpdaterExeFilename);
		}
		for (const std::string& filename : Updater::LegacyCleanupFiles) {
			if (std::filesystem::exists(filename)) {
				Logger::Info("Deleting legacy file %s...\n", filename.c_str());
				std::filesystem::remove(filename);
			}
		}
	} catch (std::filesystem::filesystem_error& err) {
		Logger::Error("Error trying to clean up installation: %s\n", err.what());
	}
}

void Updater::TryRepairInstallation(HWND mainWindow) {
	if (!Updater::CheckInstallationIntegrity()) {
		Logger::Info("Incomplete or broken installation detected. Verifying...\n");
		if (UnfinishedUpdateMarkerExists()) {
			Logger::Error("Detected failed update!\n");
			ShowMessageBox(mainWindow, "A previous attempt to update the launcher failed. "
				"Will attempt to roll back to your previous installation. "
				"More details may be found in updater.log.\n\n"
				"If this issue persists, please report it. "
				"If needed, you may also manually download the latest version of the launcher from `REPENTOGON.COM`.\n", MB_ICONERROR);

			// Check for a backup of the bin file from before the update attempt.
			if (Filesystem::SafeExists(LauncherBinBackupFilename)) {
				Logger::Info("Restoring %s...\n", LauncherBinBackupFilename);
				if (Filesystem::SafeExists(LauncherBinFilename)) {
					std::filesystem::remove(LauncherBinFilename);
				}
				std::filesystem::rename(LauncherBinBackupFilename, LauncherBinFilename);
				Logger::Info("Successfully restored backup bin!\n");
			}
		} else {
			Logger::Info("Installation incomplete, or simply first-time setup. Will attempt to extract %s...\n", LauncherBinFilename);
		}

		if (Filesystem::SafeExists(LauncherDataFolder) && !Filesystem::OneDriveSafeDelete(LauncherDataFolder)) {
			Logger::Error("[TryRepairInstallation] Failed to delete launcher data folder!\n");
			return;
		}

		// Try extracting files from the bin.
		if (Filesystem::SafeExists(LauncherBinFilename)) {
			Logger::Info("Extracting %s...\n", LauncherBinFilename);
			std::filesystem::create_directories(LauncherDataFolder);
			CreateUnfinishedUpdateMarker();
			if (!Zip::ExtractAllToFolder(LauncherBinFilename, LauncherDataFolder)) {
				Logger::Error("Extraction of `%s` failed.\n", LauncherBinFilename);
				if (!Filesystem::OneDriveSafeDelete(LauncherDataFolder)) {
					Logger::Error("[TryRepairInstallation] Failed to delete launcher data folder!\n");
					return;
				}
			} else {
				DeleteUnfinishedUpdateMarker();
				Logger::Info("...done!\n");
				return;
			}
		}

		// Try restoring a backup folder.
		if (Filesystem::SafeExists(LauncherDataBackupFolder)) {
			Logger::Info("Restoring backup installation folder...\n");
			std::filesystem::rename(LauncherDataBackupFolder, LauncherDataFolder);
			Logger::Info("Successfully restored backup folder!\n");
		} else {
			Logger::Warn("Unable to restore backups or install from bin. Will attempt to force update...\n");
		}
	}
}

void Updater::CheckSteamAppIdTxt() {
	if (!Filesystem::SafeExists("steam_appid.txt")) {
		Logger::Warn("steam_appid.txt is missing. Generating one...\n");
		std::ofstream outFile("steam_appid.txt");
		if (outFile) {
			outFile << "250900";
			outFile.close();
		} else {
			Logger::Error("Failed to generate steam_appid.txt!\n");
		}
	}
}

constexpr UINT_PTR IDC_CANCEL_BUTTON = 101;
constexpr UINT_PTR IDC_STATUS_LABEL = 102;

LRESULT CALLBACK ProgressBarWndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	if (uMsg == WM_COMMAND) {
		if (LOWORD(wParam) == IDC_CANCEL_BUTTON && HIWORD(wParam) == BN_CLICKED) {
			EnableWindow((HWND)lParam, FALSE);
			Updater::_cancelRequested.store(true);
			Logger::Info("User clicked cancel button.\n");
			return 0;
		}
	}
	return DefWindowProcA(hwnd, uMsg, wParam, lParam);
}

std::unique_ptr<Updater::UniqueWindow> Updater::CreateProgressBarWindow(POINT windowPos) {
	HINSTANCE hInstance = GetModuleHandle(NULL);

	WNDCLASSEX windowClass = {};

	if (!GetClassInfoExA(hInstance, "SelfUpdaterProgressBar", &windowClass)) {
		windowClass.cbSize = sizeof(windowClass);
		windowClass.lpszClassName = "SelfUpdaterProgressBar";
		windowClass.hbrBackground = (HBRUSH)(COLOR_WINDOW);
		windowClass.lpfnWndProc = ProgressBarWndProc;
		windowClass.hInstance = hInstance;
		windowClass.style = windowClass.style | CS_NOCLOSE;

		windowClass.hIconSm = (HICON)LoadImageA(hInstance, "IDI_ICON1", IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), LR_DEFAULTCOLOR);
		windowClass.hIcon = (HICON)LoadImageA( hInstance, "IDI_ICON1", IMAGE_ICON, GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CYICON), LR_DEFAULTCOLOR);
		
		if (!RegisterClassExA(&windowClass)) {
			Logger::Error("Error registering progress bar window class (%d)\n", GetLastError());
			return nullptr;
		}
	}

	// Create main window
	auto window = std::make_unique<UniqueWindow>(nullptr, windowClass.lpszClassName,
		Updater::UpdaterProcessName, WS_POPUPWINDOW | WS_CAPTION | WS_SYSMENU,
		windowPos.x - 225, windowPos.y - 30, 450, 120, windowClass.hInstance);
	HWND windowHandle = window->GetHandle();
	if (windowHandle == NULL) {
		Logger::Error("Error creating progress bar window (%d)\n", GetLastError());
		return nullptr;
	}

	// Add progress bar to window
	HWND progressBar = CreateWindowExA(0, PROGRESS_CLASS, NULL, WS_CHILD | WS_VISIBLE | PBS_MARQUEE, 15, 15, 400, 25, windowHandle, NULL, windowClass.hInstance, NULL);
	if (progressBar == NULL) {
		Logger::Error("Error initializing progress bar (%d)\n", GetLastError());
		return nullptr;
	}
	SendMessageA(progressBar, PBM_SETMARQUEE, TRUE, NULL);

	// Add status label
	HWND statusLabel = CreateWindowExA(0, "STATIC", "", WS_CHILD | WS_VISIBLE | SS_LEFT, 15, 53, 310, 28, windowHandle, (HMENU)IDC_STATUS_LABEL, windowClass.hInstance, NULL);
	if (statusLabel == NULL) {
		Logger::Error("Error creating progress bar status label (%d)\n", GetLastError());
		return nullptr;
	}
	HFONT hFont = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
	SendMessageA(statusLabel, WM_SETFONT, (WPARAM)hFont, TRUE);

	// Add cancel button
	HWND cancelButton = CreateWindowExA(0, "BUTTON", "Cancel", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 335, 48, 80, 26, windowHandle, (HMENU)IDC_CANCEL_BUTTON, windowClass.hInstance, NULL);
	if (cancelButton == NULL) {
		Logger::Error("Error creating progress bar cancel button (%d)\n", GetLastError());
		return nullptr;
	}
	ShowWindow(cancelButton, SW_HIDE);
	EnableWindow(cancelButton, FALSE);

	// Finish window init
	ShowWindow(windowHandle, SW_SHOWDEFAULT);
	if (!UpdateWindow(windowHandle)) {
		Logger::Error("Error finalizing progress bar window (%d)\n", GetLastError());
		return nullptr;
	}

	return window;
}

void Updater::ProgressBarThread(POINT windowPos) {
	std::unique_ptr<Updater::UniqueWindow> progressBarWindow = nullptr;

	UpdaterState state = UPDATER_STARTUP;

	MSG msg = {};

	std::chrono::steady_clock::time_point lastStateChange = std::chrono::steady_clock::now();
	bool enabledCancelButton = false;

	while (true) {
		while (PeekMessageA(&msg, NULL, 0, 0, PM_REMOVE)) {
			TranslateMessage(&msg);
			DispatchMessageA(&msg);
			if (msg.message == WM_QUIT) {
				break;
			}
		}

		const UpdaterState currentState = GetCurrentUpdaterState();
		if (currentState == UpdaterState::UPDATER_RUNNING_LAUNCHER || currentState == UpdaterState::UPDATER_SHUTTING_DOWN) {
			// Progress bar no longer needed. Allow the thread to terminate.
			break;
		} else if (currentState != state) {
			state = currentState;
			lastStateChange = std::chrono::steady_clock::now();

			if (UpdaterStateProgressBarLabels.find(state) != UpdaterStateProgressBarLabels.end()) {
				if (!progressBarWindow) {
					progressBarWindow = Updater::CreateProgressBarWindow(windowPos);
					if (!progressBarWindow) {
						Logger::Error("Failed to create progress bar window\n");
						break;
					}
				}
				// Re-enable the window and resume the marquee if needed.
				if (EnableWindow(progressBarWindow->GetHandle(), TRUE)) {
					if (HWND progressBar = FindWindowExA(progressBarWindow->GetHandle(), NULL, PROGRESS_CLASS, NULL)) {
						SendMessageA(progressBar, PBM_SETSTATE, PBST_NORMAL, 0);
					}
				}
				SetForegroundWindow(progressBarWindow->GetHandle());

				// Update the current status label
				HWND statusLabel = GetDlgItem(progressBarWindow->GetHandle(), IDC_STATUS_LABEL);
				if (statusLabel && !SetWindowTextA(statusLabel, UpdaterStateProgressBarLabels.at(state))) {
					Logger::Error("Error trying to set progress bar status label (%d)\n", GetLastError());
					break;
				}

				if (enabledCancelButton) {
					if (HWND cancelButton = GetDlgItem(progressBarWindow->GetHandle(), IDC_CANCEL_BUTTON)) {
						EnableWindow(cancelButton, FALSE);
					}
				}
			} else if (progressBarWindow) {
				// Disable the progress bar window and stop the marquee (most likely the user is being prompted)
				if (!EnableWindow(progressBarWindow->GetHandle(), FALSE)) {
					if (HWND progressBar = FindWindowExA(progressBarWindow->GetHandle(), NULL, PROGRESS_CLASS, NULL)) {
						SendMessageA(progressBar, PBM_SETSTATE, PBST_PAUSED, 0);
					}
				}
			}
		} else if (!enabledCancelButton && state == UpdaterState::UPDATER_CHECKING_FOR_UPDATE) {
			int64_t secondsElapsed = std::chrono::duration_cast<std::chrono::seconds>(std::chrono::steady_clock::now() - lastStateChange).count();
			if (secondsElapsed >= 5) {
				if (HWND cancelButton = GetDlgItem(progressBarWindow->GetHandle(), IDC_CANCEL_BUTTON)) {
					ShowWindow(cancelButton, SW_SHOW);
					EnableWindow(cancelButton, TRUE);
				}
				enabledCancelButton = true;
			}
		}
	}

	Logger::Info("Progress bar thread ended.\n");
}

Updater::SelfUpdateCheckInfo Updater::SelfUpdateCheckThread(std::shared_ptr<Updater::LauncherUpdateManager> manager, const bool allowUnstable, const bool forceUpdate) {
	std::string version;
	std::string url;
	LauncherUpdateManager::SelfUpdateCheckResult checkResult = manager->CheckSelfUpdateAvailability(allowUnstable, forceUpdate, version, url);
	return SelfUpdateCheckInfo(std::move(version), std::move(url), checkResult);
}

Updater::UpdateLauncherResult Updater::TryUpdateLauncher(int argc, char** argv, HWND mainWindow) {
	Logger::Info("TryUpdateLauncher started.\n");

	// Validate that no other instance of the updater is running.
	HANDLE lockFile = NULL;

	Utils::LockUpdaterResult lockResult = Utils::LockUpdater(&lockFile);

	if (lockResult != Utils::LOCK_UPDATER_SUCCESS) {
		bool isForced = Utils::IsForced(argc, argv);

		if (!isForced) {
			if (lockResult == Utils::LOCK_UPDATER_ERR_INTERNAL) {
				ShowMessageBox(mainWindow, "Unable to check if another instance of the updater is already running\n"
					"Check the log file (you may need to launch Isaac normaly at least once; otherwise rerun with --force)\n",
					MB_ICONERROR);
				Logger::Error("Error while attempting to lock the updater\n");
			}
			else {
				ShowMessageBox(mainWindow, "Another instance of the updater is already running, "
					"terminate it first then restart the updater\n"
					"(If no other instance of the updater is running, rerun with --force)\n", MB_ICONERROR);
				Logger::Error("Launcher updater is already running, terminate other instances first\n");
			}

			return UPDATE_ERROR;
		}
		else {
			Logger::Warn("Cannot take updater lock, but ignoring (--force given)\n");
		}
	}

	Updater::Utils::ScopedHandle scopedHandle(lockFile);

	// Verify integrity of installation, detect unfinished updates or broken/incomplete installs, and attempt repair if needed.
	if (!CheckInstallationIntegrity()) {
		TryRepairInstallation(mainWindow);
	}
	if (CheckInstallationIntegrity()) {
		CleanInstallation();
	}
	CheckSteamAppIdTxt();

	SetCurrentUpdaterState(UPDATER_CHECKING_FOR_UPDATE);

	// Check for available updates.
	using lu = LauncherUpdateManager;
	auto updateManager = std::make_shared<LauncherUpdateManager>();

	const bool allowUnstable = Utils::AllowUnstable(argc, argv);
	if (allowUnstable) {
		Logger::Info("Fetching unstable releases is enabled.\n");
	}

	const char* versionGiven = Utils::GetUpdateVersion(argc, argv);
	const char* urlGiven = Utils::GetUpdateURL(argc, argv);

	std::string version;
	std::string url;

	if (urlGiven) {
		url = urlGiven;
	}

	if (versionGiven) {
		version = versionGiven;
	}

	const bool forceUpdate = !Filesystem::SafeExists(LauncherDllPath);
	const bool skipConfirmation = urlGiven || forceUpdate;

	if (!urlGiven) {
		// Check for updates on a separate (non-blocking) thread, so that in case it hangs (on something like the dns) we can give the user the option to cancel.
		auto updateCheckTask = std::make_shared<std::packaged_task<SelfUpdateCheckInfo()>>(
			[=]() { return SelfUpdateCheckThread(updateManager, allowUnstable, forceUpdate); }
		);
		std::future<SelfUpdateCheckInfo> updateCheckFuture = updateCheckTask->get_future();
		std::thread updateCheckThread([updateCheckTask]() { (*updateCheckTask)(); });
		updateCheckThread.detach();

		std::future_status status;
		do {
			if (_cancelRequested.load()) {
				Logger::Info("User requested to cancel update check.\n");
				return UPDATE_SKIPPED;
			}

			status = updateCheckFuture.wait_for(std::chrono::milliseconds(20));
		} while (status != std::future_status::ready);

		SelfUpdateCheckInfo updateCheckInfo = updateCheckFuture.get();
		lu::SelfUpdateCheckResult checkResult = updateCheckInfo.result;
		if (!updateCheckInfo.url.empty()) {
			url = updateCheckInfo.url;
		}
		if (!updateCheckInfo.version.empty()) {
			version = updateCheckInfo.version;
		}

		switch (checkResult) {
		case lu::SELF_UPDATE_CHECK_UP_TO_DATE:
			if (forceUpdate) {
				Logger::Warn("Launcher DLL missing. Forcing update to version: %s (from %s)\n", version.c_str(), url.c_str());
			} else {
				Logger::Info("launcher is already up-to-date.\n");
				return UPDATE_ALREADY_UP_TO_DATE;
			}
			break;

		case lu::SELF_UPDATE_CHECK_ERR_GENERIC:
		case lu::SELF_UPDATE_CHECK_STEAM_METHOD_FAILED:
			Logger::Error("Error while checking for updates.\n");
			return UPDATE_CHECK_FAILED;

		case lu::SELF_UPDATE_CHECK_UPDATE_AVAILABLE:
			Logger::Info("Found available update version: %s (from %s)\n", version.c_str(), url.c_str());
			break;

		default:
			SetCurrentUpdaterState(UPDATER_FAILED);
			ShowMessageBox(mainWindow, "An unknown error was encountered while checking for the availability of updates. Check the log file for more details.\n", MB_ICONERROR);
			Logger::Error("Recieved unexpected error code %d while checking for availability of self updates. Please report this as a bug.\n", checkResult);
			return UPDATE_ERROR;
		}
	}

	// Check for a renamed updater exe from a previous update and try to delete it if found.
	// Since we have the lockfile to prevent multiple instances of the updater running at the same time,
	// we shouldn't ever fail to delete it, but you never know...
	if (!TryDeleteOldRenamedUpdaterExe(mainWindow)) {
		return UPDATE_ERROR;
	}

	if (!skipConfirmation) {
		SetCurrentUpdaterState(UPDATER_PROMPTING_USER);

		// An appropriate update is available. Prompt the user about it.
		const std::string updatePrompt = (std::ostringstream() << "An update is available for the launcher.\n" <<
			"It will update from version " << Launcher::LAUNCHER_VERSION << " to version " << version << ".\n\n" <<
			"Do you want to update now?").str();

		int updatePromptResult = ShowMessageBox(mainWindow, updatePrompt.c_str(), MB_ICONINFORMATION | MB_YESNO);
		if (updatePromptResult != IDOK && updatePromptResult != IDYES) {
			Logger::Info("Launcher updated rejected by user\n");
			return UPDATE_SKIPPED;
		}
	}

	SetCurrentUpdaterState(UPDATER_DOWNLOADING_UPDATE);

	Logger::Info("Starting update download from %s\n", url.c_str());

	std::string updateZipFilename;

	if (!updateManager->DownloadUpdate(url, updateZipFilename)) {
		SetCurrentUpdaterState(UPDATER_FAILED);
		ShowMessageBox(mainWindow, "Failed to download the update for the launcher. Check the log file for more details.\n", MB_ICONERROR);
		Logger::Error("Error trying to download update from URL: %s\n", url.c_str());
		return UPDATE_ERROR;
	}

	if (updateZipFilename.empty()) {
		SetCurrentUpdaterState(UPDATER_FAILED);
		ShowMessageBox(mainWindow, "Failed to download the update for the launcher. Check the log file for more details.\n", MB_ICONERROR);
		Logger::Error("No zip file found after downloading update from URL: %s\n", url.c_str());
		return UPDATE_ERROR;
	}

	Logger::Info("Downloaded update zip file: %s\n", updateZipFilename.c_str());

	SetCurrentUpdaterState(UPDATER_INSTALLING_UPDATE);

	// Check if the launcher dlls are locked. If so, prompt the user about it.
	// Files could remain locked briefly after termination, so we check this after the download.
	if (!VerifyLauncherNotRunning(mainWindow)) {
		return UPDATE_ERROR;
	}

	if (Filesystem::SafeExists(LauncherDataBackupFolder)) {
		Logger::Info("Deleting backup of previous version...\n");
		if (!Filesystem::OneDriveSafeDelete(LauncherDataBackupFolder)) {
			Logger::Info("Failed to delete pre-existing backup. Cannot continue.\n");
			return UPDATE_ERROR;
		}
	}
	if (Filesystem::SafeExists(LauncherDataFolder)) {
		Logger::Info("Backing up current version...\n");
		std::filesystem::rename(LauncherDataFolder, LauncherDataBackupFolder);
	}
	if (Filesystem::SafeExists(LauncherBinFilename)) {
		Logger::Info("Backing up current bin...\n");
		std::filesystem::copy(LauncherBinFilename, LauncherBinBackupFilename, std::filesystem::copy_options::overwrite_existing);
	}
	Logger::Info("Initializing directory for new version...\n");
	std::filesystem::create_directories(LauncherDataFolder);
	CreateUnfinishedUpdateMarker();

	// The updater cannot directly overwrite its own currently-running exe with the new one from the update.
	// To get around this, we do the following:
	//   1. Rename the existing exe as `exe.bak`. Windows lets us rename a file thats in use, but the file remains locked until this program ends.
	//   2. Make a copy of the existing exe under the original name, just in case we encounter an error during unpacking and can't write the new exe.
	// So the result of this is that the running exe has been renamed as `exe.bak` (and is still locked by windows),
	// AND we have a copy under the original name (which is not locked and can be overwritten).
	if (Filesystem::SafeExists(UpdaterExeFilename)) {
		Logger::Info("Renaming exe...\n");
		std::filesystem::rename(UpdaterExeFilename, RenamedUpdaterExeFilename);
		Logger::Info("Copying exe...\n");
		try {
			std::filesystem::copy(RenamedUpdaterExeFilename, UpdaterExeFilename);
		} catch (std::filesystem::filesystem_error& err) {
			Logger::Error("Error trying to create copy of own executable: %s", err.what());
			// Ahhh! Attempt to recover.
			std::filesystem::rename(RenamedUpdaterExeFilename, UpdaterExeFilename);
			ShowMessageBox(mainWindow, "Error backing up files for update, see updater.log\n", MB_ICONERROR);
			return UPDATE_ERROR;
		}
	}

	// Initialize the staging folder.
	if (Filesystem::SafeExists(UpdateStagingFolder)) {
		Logger::Warn("Deleting an existing staging folder...\n");
		if (!Filesystem::OneDriveSafeDelete(UpdateStagingFolder)) {
			Logger::Error("Failed to delete existing staging folder. Cannot continue.\n");
			return UPDATE_ERROR;
		}
	}
	Logger::Info("Creating staging folder...\n");
	std::filesystem::create_directories(UpdateStagingFolder);

	// Extract update zip contents to staging folder.
	Logger::Info("Extracting update to staging folder...\n");
	if (!Zip::ExtractAllToFolder(updateZipFilename.c_str(), UpdateStagingFolder)) {
		SetCurrentUpdaterState(UPDATER_FAILED);
		ShowMessageBox(mainWindow, "Unable to extract the update, see updater.log\n", MB_ICONERROR);
		Logger::Error("Error while extracting archive\n");
		return UPDATE_ERROR;
	}

	// Copy files from the staging folder into the current folder, overwriting any existing files with the same names.
	Logger::Info("Copying files from staging folder...\n");

	if (!Filesystem::OneDriveSafeCopy(UpdateStagingFolder, std::filesystem::current_path())) {
		Logger::Error("Failed to copy file(s)!\n");
		try {
			std::filesystem::copy(UpdaterExeFilename, RenamedUpdaterExeFilename, std::filesystem::copy_options::overwrite_existing);
		} catch (std::filesystem::filesystem_error& err) {
			Logger::Error("Failed to restore original exe: %s", err.what());
		}
		// Due to the precense of the unfinished update marker, the next launch will attempt to roll back or repair the installation.
		return UPDATE_ERROR;
	}

	Logger::Info("Deleting 'unfinished update' marker...\n");
	DeleteUnfinishedUpdateMarker();

	Logger::Info("Update successful!\n");
	return UPDATE_SUCCESSFUL;
}

void SetWorkingDirToExe() {
	wchar_t exePath[MAX_PATH];
	GetModuleFileNameW(NULL, exePath, MAX_PATH);
	std::filesystem::path exeDir = std::filesystem::path(exePath).parent_path();
	SetCurrentDirectoryW(exeDir.wstring().c_str());
}

std::string Updater::BuildCleanCli(int argc, char** argv, bool addCheckSelfUpdate) {
	std::ostringstream cli;
	cli << UpdaterExeFilename;
	for (int i = 0; i < argc; ++i) {
		if (strcmp(argv[i], ForcedArg) == 0 || strcmp(argv[i], CheckSelfUpdateLauncherArg) == 0) {
			continue;
		}
		if (strcmp(argv[i], ReleaseURL) == 0 || strcmp(argv[i], UpgradeVersion) == 0 || strcmp(argv[i], LauncherProcessIdArg) == 0) {
			i++;
			continue;
		}
		cli << " \"" << argv[i] << "\"";
	}
	if (addCheckSelfUpdate) {
		cli << " " << CheckSelfUpdateLauncherArg;
	}
	return cli.str();
}

typedef int(__stdcall* LAUNCHERPROC)(int argc, char** argv);

int Updater::RunLauncher(HWND mainWindow, int argc, char** argv, bool checkUpdates) {
	Updater::SetCurrentUpdaterState(Updater::UPDATER_STARTING_LAUNCHER);

	// This is dumb but helps avoid focus issues while the progress bar thread kills itself.
	std::this_thread::sleep_for(std::chrono::milliseconds(100));

	Logger::Info("Preparing to start launcher...\n");

	std::filesystem::path launcherDllFullPath(LauncherDllPath);

	try {
		launcherDllFullPath = std::filesystem::absolute(launcherDllFullPath);
	} catch (std::filesystem::filesystem_error const& ex) {
		std::string err = "Filesystem error locating REPENTOGONLauncherApp.dll: " + std::string(ex.what()) + "\n";
		ShowMessageBox(mainWindow, err.c_str(), MB_ICONERROR);
		Logger::Error(err.c_str());
		return -1;
	}

	HINSTANCE launcher = LoadLibraryExW(launcherDllFullPath.wstring().c_str(), NULL, LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR | LOAD_LIBRARY_SEARCH_SYSTEM32);
	if (launcher == NULL) {
		std::string err = "Failed to load REPENTOGONLauncherApp.dll: " + std::to_string(GetLastError()) + "\n";
		ShowMessageBox(mainWindow, err.c_str(), MB_ICONERROR);
		Logger::Error(err.c_str());
		return -1;
	}

	LAUNCHERPROC proc = (LAUNCHERPROC)GetProcAddress(launcher, "_StartLauncherApp@8");
	if (proc == NULL) {
		std::string err = "Failed to start launcher: " + std::to_string(GetLastError()) + "\n";
		ShowMessageBox(mainWindow, err.c_str(), MB_ICONERROR);
		Logger::Error(err.c_str());
		return -1;
	}

	const std::string cli = BuildCleanCli(argc, argv, checkUpdates);
	int newargc = 0;
	char** newargv = Utils::CommandLineToArgvA(cli.c_str(), &newargc);

	SetCurrentUpdaterState(UPDATER_RUNNING_LAUNCHER);
	Logger::Info("Starting launcher with cli: %s\n", cli.c_str());
	SetForegroundWindow(mainWindow);
	int res = proc(newargc, newargv);
	Logger::Info("Launcher application closed with return code %d\n", res);
	Utils::FreeCli(newargc, newargv);
	FreeLibrary(launcher);

	return res;
}

bool Updater::Restart(int argc, char** argv) {
	SetCurrentUpdaterState(UPDATER_SHUTTING_DOWN);

	STARTUPINFOA startup;
	memset(&startup, 0, sizeof(startup));

	PROCESS_INFORMATION info;
	memset(&info, 0, sizeof(info));

	std::string cli = BuildCleanCli(argc, argv, false);

	Logger::Info("Restarting: %s\n", cli.c_str());
	bool result = CreateProcessA(UpdaterExeFilename, (LPSTR)cli.c_str(), NULL, NULL, FALSE, 0, NULL, NULL, &startup, &info);
	if (!result) {
		Logger::Error("Restart failed: %d\n", GetLastError());
	}
	CloseHandle(info.hProcess);
	CloseHandle(info.hThread);

	return result;
}



int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR cli, int) {
	SetWorkingDirToExe();
	Logger::Init("updater.log", true);
	Logger::Info("Updater version %s started with command-line args: %s\n", Launcher::LAUNCHER_VERSION, cli);
	Logger::Info("Current Directory: %s\n", std::filesystem::current_path().u8string().c_str());

	int argc = 0;
	char** argv = Updater::Utils::CommandLineToArgvA(cli, &argc);

	// Open a handle for the prior launcher process, if provided, and kill it.
	if (HANDLE launcherHandle = Updater::TryOpenLauncherProcessHandle(argc, argv); launcherHandle != INVALID_HANDLE_VALUE) {
		Logger::Info("Restart detected. Terminating previous launcher instance...\n");
		if (TerminateProcess(launcherHandle, 0)) {
			WaitForSingleObject(launcherHandle, INFINITE);
		} else {
			// We can continue on after this and hope for the best.
			Logger::Error("Failed to terminate launcher process (%d)\n", GetLastError());
		}
		CloseHandle(launcherHandle);
	}

	sGithubExecutor->Start();

	// Create a dummy window to use as a parent for popups.
	Updater::UniqueWindow mainWindow(NULL, "STATIC", NULL, NULL, CW_USEDEFAULT, CW_USEDEFAULT, 1, 1, hInstance);

	// Get the center of the appropriate monitor.
	HMONITOR monitor = MonitorFromWindow(mainWindow, MONITOR_DEFAULTTONEAREST);
	MONITORINFO monitorInfo{ sizeof(monitorInfo) };
	GetMonitorInfo(monitor, &monitorInfo);
	POINT screenCenter{ (monitorInfo.rcWork.left + monitorInfo.rcWork.right) / 2, (monitorInfo.rcWork.top + monitorInfo.rcWork.bottom) / 2 };

	// Start up a progress bar window on a separate thread so that we can show some not-frozen UI to the user.
	std::thread progressBarThread(Updater::ProgressBarThread, screenCenter);
	progressBarThread.detach();

	Updater::UpdateLauncherResult result = Updater::TryUpdateLauncher(argc, argv, mainWindow);

	int res = -1;

	switch (result) {
	case Updater::UPDATE_ALREADY_UP_TO_DATE:
	case Updater::UPDATE_SKIPPED:
	case Updater::UPDATE_CHECK_FAILED:
		// Run the launcher!
		res = Updater::RunLauncher(mainWindow, argc, argv, result == Updater::UPDATE_CHECK_FAILED);
		break;

	case Updater::UPDATE_SUCCESSFUL:
		// Restart before starting the launcher in case we made changes to the updater.
		res = !Updater::Restart(argc, argv);
		break;

	case Updater::UPDATE_ERROR:
		res = -1;
		break;

	default:
		Logger::Error("Unexpected update result value: %d", result);
		res = -1;
		break;
	}

	Updater::SetCurrentUpdaterState(Updater::UPDATER_SHUTTING_DOWN);

	sGithubExecutor->Stop();

	return res;
}